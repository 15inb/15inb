const Discord = require("discord.js");
const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");


//Connect to Database
mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});


//MODELS
const Data = require("../models/data.js");

const options = [
    '🇦',
    '🇧',
    '🇨',
    '🇩',
    '🇪',
    '🇫',
    '🇬',
    '🇭',
    '🇮',
    '🇯',
    '🇰',
    '🇱',
    '🇲',
    '🇳',
    '🇴',
    '🇵',
    '🇶',
    '🇷',
    '🇸',
    '🇹',
    '🇺',
    '🇻',
    '🇼',
    '🇽',
    '🇾',
    '🇿',
  ];


module.exports.run = async (bot, message) => {

  if (message.channel.type === "dm") return;

    const args = message.content.trim().split(/ +/g);

// Defining the question...
let question = [];

for (let i = 1; i < args.length; i++) {
  if (args[i].startsWith('"')) break;
  else question.push(args[i]);
}

question = question.join(' ');

// Defining the choices...
const choices = [];

const regex = /(["'])((?:\\\1|\1\1|(?!\1).)*)\1/g;
let match;
while (match = regex.exec(args.join(' '))) choices.push(match[2]);

// Creating and sending embed...
let content = [];
for (let i = 0; i < choices.length; i++) content.push(`${options[i]} ${choices[i]}`);
content = content.join('\n');

let embed = new Discord.MessageEmbed()
  embed.setColor('#8CD7FF')
  embed.setTitle(`**${question}**`)
  embed.setDescription(content);

message.channel.send({ content: `:bar_chart: ${message.author} started a poll.`, embeds: embed})
  .then(async m => {
    for (let i = 0; i < choices.length; i++) await m.react(options[i]);
  });
  message.delete()

}    
module.exports.help = {
    name: "poll",
    aliases: []
}