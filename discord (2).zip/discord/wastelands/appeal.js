const Discord = require("discord.js");


module.exports.run = async (client, message, args) => {

    if (message.channel.type !== "dm") return;

    let embed = new Discord.MessageEmbed()
    embed.setTitle(`Command Failed`)
    embed.setDescription(`No reason was specified`)

    let appealreason = args.slice(0).join(" ");
    if(!appealreason) return message.channel.send(embed)

    let embed2 = new Discord.MessageEmbed()
    embed2.setTitle(`Discord Ban Appeal`)
    embed2.addField(`${message.author.tag} has requested to be unbanned`, `Reason: ${appealreason}`)

    let embed3 = new Discord.MessageEmbed()
    embed3.setTitle(`Appeal Successfully Sent`)
    embed3.addField(`Your appeal has been sent`, `Please be patient as it may take some time for you to be unbanned`)

    message.channel.send({ embeds: embed3 })

    client.channels.cache.get('981774205001551913').send({ embeds: embed2 })

}

module.exports.help = {
    name: "appeal",
    aliases: []
}
