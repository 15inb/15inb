const Discord = require(`discord.js`)


module.exports.run = async (client, message, args) => {

if (message.channel.type === "dm") return;

let embedfail = new Discord.MessageEmbed()
embedfail.setTitle(`Error`)
embedfail.addField(`Command failed`, `Miss permissions: BAN_MEMBERS`)
embedfail.setColor(`#FF0000`)
embedfail.setTimestamp()

let embedfail2 = new Discord.MessageEmbed()
embedfail2.setTitle(`Error`)
embedfail2.addField(`Command failed`, `Failed to mention a user to ban`)
embedfail2.setColor(`#FF0000`)
embedfail2.setTimestamp()

let embedfail3 = new Discord.MessageEmbed()
embedfail3.setTitle(`Error`)
embedfail3.addField(`Command failed`, `Failed to specify a reason`)
embedfail3.setColor(`#FF0000`)
embedfail3.setTimestamp()


let embedfail4 = new Discord.MessageEmbed()
embedfail4.setTitle(`Error`)
embedfail4.addField(`Command failed`, `This user can not be banned`)
embedfail4.setColor(`#FF0000`)
embedfail4.setTimestamp()

let embedfail5 = new Discord.MessageEmbed()
embedfail4.setTitle(`Error`)
embedfail4.addField(`Command failed`, `You must have a channel named moderation-logs`)
embedfail4.setColor(`#FF0000`)
embedfail4.setTimestamp()

// Checks members permission to ban
if(!message.member.hasPermission('BAN_MEMBERS')) {
    message.channel.send(embedfail);
    return;
};

// Checks if a user was specified
let member = message.mentions.members.first()
if(!member) return message.channel.send({ embeds: embedfail2 })

// Checks to see if a ban reason was specified
let banreason = args.slice(1).join(" ");
if(!banreason) return message.channel.send({ embeds: embedfail3 })

// Checks to see if the user is bannable or not
if(!member.bannable) return message.channel.send({ embeds: embedfail4 })


let bansuccess = new Discord.MessageEmbed()
bansuccess.setTitle(`User Banned`)
bansuccess.addField(`${member.user.tag} has been banned by ${message.author.tag}`, `Reason: ${banreason}`)
bansuccess.setColor(`#00FF00`)
bansuccess.setTimestamp()

let bansuccess2 = new Discord.MessageEmbed()
bansuccess2.setTitle(`You've been banned`)
bansuccess2.addField(`You have been banned by ${message.author.tag} from the Wastelands' Discord`, `Reason: ${banreason}`)
bansuccess2.setColor(`#00FF00`)
bansuccess2.setFooter(`If you believe you were falsly banned please do >appeal with a reason as to why you should be unbanned`)
bansuccess2.setTimestamp()

const moderationlog = message.guild.channels.cache.find(ch => ch.name ==="moderation-logs");
if(!moderationlog) return message.channel.send({ embeds: embedfail5 })
member.ban({reason: banreason})
message.member.send({ embeds: bansuccess2 })
moderationlog.send({ embeds: bansuccess })
message.delete()
}


module.exports.help = {
    name: "ban",
    aliases: []
}