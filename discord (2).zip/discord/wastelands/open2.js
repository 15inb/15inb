const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {


    if (message.channel.type === "dm") return;
    
    // ID from the catogory channel tickets.
    const categoryId = "644626077704257546";

    if (!args[0]) return message.channel.send(`Please put the ID of the user you wish to have on the ticket`)

    // Get username
    var userName = message.author.username;
    // Verkrijg discriminator
    var userDiscriminator = message.author.discriminator;

    if (message.guild.id !==(`979892448899788830`)) return

    let embed = new Discord.MessageEmbed()
    embed.setTitle(`Command failed`)
    embed.setFooter(`You may only use this command for tickets`)

    let embed2 = new Discord.MessageEmbed()
    embed2.setTitle(`Command failed`)
    embed2.setFooter(`You may only use this command if you are staff.`)

    if(message.channel.parent.id !== `979925186268766279`) return message.channel.send({ embeds: embed });
    if(message.member.roles.cache.some(role => role.name === 'Staff Team')){

    bot.users.cache.get(`${args[0]}`).send(`Your ticket has been unarchived by ${message.author}`)
    bot.channels.cache.get('979956782371856395').send({ content: `Ticket ${message.channel.name} has been unarchived by ${message.author}`})
    message.channel.send({content: `This ticket has been unarchived. It can be rearchived with >close or >closeticket`})
    message.channel.updateOverwrite(args[0], {
        VIEW_CHANNEL: true, SEND_MESSAGES: true, ATTACH_FILES: true, ADD_REACTIONS: true
    });
    message.channel.setName(args[0])
    } else {
        message.channel.send(embed2)
    }
}

module.exports.help = {
    name: "open",
    aliases: ["openticket"]
}