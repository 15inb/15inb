const discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

    if (message.channel.type === "dm") return;

    // ID from the catogory channel tickets.
    const categoryId = "644626077704257546";

    // Get username
    var userName = message.author.username;
    // Verkrijg discriminator
    var userDiscriminator = message.author.id;

    // If ticket has been made
    var bool = false;

    if (message.guild.id !==(`979892448899788830`)) return

    // Checking if ticket has been made.
    message.guild.channels.cache.forEach((channel) => {

        // If ticket has been made sent:
        if (channel.name == userDiscriminator && message.channel.parent.id == `979925186268766279`) {
            message.channel.send({ content: `You've already made a ticket`});
            bool = true;
        }

    });

    // Ticket return code
    if (bool == true) return;

    let embed = new discord.MessageEmbed()
        embed.setTitle("Hello " + message.author.username)
        embed.addField(`Your support channel has been created`, `It is named: ${userDiscriminator}`);
        message.author.send({embeds: embed});
        message.delete()

    // Create channel and put it in the right catogary
    message.guild.channels.create(userDiscriminator, "text").then((createdChan) => { // Maak kanaal

        createdChan.setParent(`979925186268766279`).then((settedParent) => { // Zet kanaal in category.

            // Put permissions for everyone
            settedParent.updateOverwrite(`979892448899788830`, { VIEW_CHANNEL: false, SEND_MESSAGES: false });
            settedParent.updateOverwrite(`979925096128999484`, { VIEW_CHANNEL: true, SEND_MESSAGES: true });

            // Put permission by the user that created the ticket
            settedParent.updateOverwrite(message.author, {
                VIEW_CHANNEL: true, SEND_MESSAGES: true, ATTACH_FILES: true, ADD_REACTIONS: true
            });

            let embed2 = new discord.MessageEmbed()
                embed2.setTitle("Hello " + message.author.username.toString())
                embed2.addField(`Respond here with your question`, `If you wish to close your ticket type either >close, or >closeticket in this channel`);
                settedParent.send({embeds: embed2});
                settedParent.send(`<@&979925096128999484>`)
        }).catch(err => {
            console.log(err)
        });

    }).catch(err => {
        console.log(err)
    });

}

module.exports.help = {
    name: "ticket",
    aliases: ["support"]
}