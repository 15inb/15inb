const Discord = require("discord.js");

module.exports.run = async (client, message, args, cmd) => {


    let embed4 = new Discord.MessageEmbed()
    embed4.setTitle(`**Wasteland Commands**`)
    embed4.addField(`>ticket`, `Creates a ticket`)
    embed4.addField(`>poll`, `Creates a poll, the question MUST have a question mark. Example: >poll Do you want a soda poppy? \"Yes\" \"No\"`)
    embed4.addField(`>archive | >close | >closeticket`, `Archives a ticket, must be typed in the channel of the ticket you want archived`)
    embed4.addField(`>delete | >del`, `Deletes a ticket, must be typed in the channel of the ticket you want deleted`)
    embed4.setColor(`#a91993`)

    if (cmd == "help") {

        message.channel.send({ embeds: embed4 })

    
    }

}


module.exports.help = {
    name: "help",
    aliases: []
}