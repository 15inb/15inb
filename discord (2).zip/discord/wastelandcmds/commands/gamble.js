const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");
const talkedRecently = new Set();
const Discord = require("discord.js");


//Connect to Database
mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

//MODELS
const Data = require("../models/data.js");

module.exports.run = async (bot, message, args) => {


    let embed3 = new Discord.MessageEmbed();
    embed3.setTitle(`Error`)
    embed3.addField(`Command failed:`, `You must wait the 3 second cooldown`)
    embed3.setColor(`#fa0000`)

    if (talkedRecently.has(message.author.id)) {
        message.channel.send(embed3); return;
} else {
       // the user can type the command ... your command code goes here :)

    // Adds the user to the set so that they can't talk for a minute
    talkedRecently.add(message.author.id);
    setTimeout(() => {
      // Removes the user from the set after a minute
      talkedRecently.delete(message.author.id);
    }, 3000);
}
    
    Data.findOne({
        userID: message.author.id
    }, (err, data) => {
        if(err) console.log(err);
        if(!data) {
            const newData = new Data({
                name: message.author.username,
                userID: message.author.id,
                lb: "all",
                money: 0,
                xp: 0,
                daily: 0,
                bank: 0,
            })
            newData.save().catch(err => console.log(err));

            let embed4 = new Discord.MessageEmbed();
            embed4.setTitle(`Error`)
            embed4.addField(`Command failed:`, `You do not have any money to gamble with`)
            embed4.setColor(`#fa0000`)

            return message.reply(embed4);
        } else {


            let embed5 = new Discord.MessageEmbed();
            embed5.setTitle(`Error`)
            embed5.addField(`Command failed:`, `You do not have any money to gamble with`)
            embed5.setColor(`#fa0000`)


            if(data.money <=0) return message.reply(embed5);

            let embed6 = new Discord.MessageEmbed();
            embed6.setTitle(`Error`)
            embed6.addField(`Command failed:`, `Specify how much you wish to bet`)
            embed6.setColor(`#fa0000`)

            if(!args[0]) return message.reply(embed6);

            if(args[0].toLowerCase() == "all") args[0] = data.money;

            let embed7 = new Discord.MessageEmbed();
            embed7.setTitle(`Error`)
            embed7.addField(`Command failed:`, `You can not bet negative amounts`)
            embed7.setColor(`#fa0000`)

            if(args[0] < 0) return message.channel.send(embed7)


            let embed8 = new Discord.MessageEmbed();
            embed8.setTitle(`Error`)
            embed8.addField(`Command failed:`, `You can only enter whole numbers`)
            embed8.setColor(`#fa0000`)

            try {
                var bet = parseFloat(args[0]);
            } catch {
                return message.reply(embed8);
            }

            if(bet != Math.floor(bet)) return message.reply(embed8);

            let embed9 = new Discord.MessageEmbed();
            embed9.setTitle(`Error`)
            embed9.addField(`Command failed:`, `You do not have $${bet.toLocaleString}`)
            embed9.setColor(`#fa0000`)


            if(data.money < bet) return message.reply(embed9);


            let chances = ["win", "lose"];
            var pick = chances[Math.floor(Math.random() * chances.length)];


            if(pick == "lose") {


                data.money -= bet;
                data.total = (data.money + data.bank)
                data.save().catch(err => console.log(err));
                let embed10 = new Discord.MessageEmbed();
                embed10.setTitle(`You lost!`)
                embed10.addField(`You lost $${bet.toLocaleString()}:`, `New Balance: $${data.money.toLocaleString()} `)
                embed10.setColor(`#fa0000`)
                return message.reply(embed10)
            } else {
                data.money += bet;
                data.total = (data.money + data.bank)
                data.save().catch(err => console.log(err));
                let embed11 = new Discord.MessageEmbed();
                embed11.setTitle(`You won!`)
                embed11.addField(`You won $${bet.toLocaleString()}:`, `New Balance: $${data.money.toLocaleString()} `)
                embed11.setColor(`#00fa00`)
                return message.reply(embed11);
            }
       } 
    })
}

module.exports.help = {
    name: "gamble",
    aliases: []
}