const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");
const talkedRecently = new Set();
const Discord = require("discord.js");

//Connect to Database
mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

//MODELS
const Data = require("../models/data.js");



module.exports.run = async (client, message, args) => {

    let embed = new Discord.MessageEmbed();
    embed.setTitle(`Error`)
    embed.addField(`Command failed:`, `Specify the amount you wish to deposit`)
    embed.setColor(`#fa0000`)

    let embed2 = new Discord.MessageEmbed();
    embed2.setTitle(`Error`)
    embed2.addField(`Command failed:`, `You are unable to deposit negative amounts`)
    embed2.setColor(`#fa0000`)

    if(!args[0]) return message.reply(embed);
    if(args[0] < 1) return message.reply (embed2)


    let user = message.author.id


    Data.findOne({
        userID: message.author.id
    }, (err, authorData) => {
        if(err) console.log(err);
        if(!authorData) {
            return message.reply("You don\'t have any money to upgrade with.");
        } else {
            Data.findOne({
                userID: user.id
            }, (err, userData) => {
                if(err) console.log(err);

                
                let embed3 = new Discord.MessageEmbed();
                embed3.setTitle(`Error`)
                embed3.addField(`Command failed:`, `You do not have $${args[0].toLocaleString()}`)
                embed3.setColor(`#fa0000`)

                if(parseInt(args[0]) > authorData.money) return message.reply(embed3);

                
                if(!userData) {
                    const newData = new Data({
                        name: message.author.id.username,
                        userID: user.id,
                        lb: "all",
                        money: 0,
                        xp: 0,
                        daily: 0,
                        bank: 0,
                        upgrade: 1,
                    })
                    if(args[0].toLowerCase() == "all") args[0] = authorData.money;


                    authorData.money -= (args[0]);
                    authorData.total = authorData.money + authorData.bank
                    newData.save().catch(err => console.log(err));
                    authorData.save().catch(err => console.log(err));

                } else {


                    if(args[0].toLowerCase() == "all") args[0] = authorData.money;

                    authorData.bank += (+args[0]);
                    authorData.money += (-args[0]);
                    authorData.total = authorData.money + authorData.bank
                    authorData.save().catch(err => console.log(err));
                }
                let fix = args[0]

                
                let embed1 = new Discord.MessageEmbed();
                embed1.setTitle(`You have deposited $${fix.toLocaleString()} into your bank`)
                embed1.addField(`New Bank Balance:`, `$${authorData.bank.toLocaleString()}`)
                embed1.addField(`New Wallet Balance:`, `$${authorData.money.toLocaleString()}`)
                embed1.setColor(`#1000c2`)


                return message.channel.send(embed1);
            })

        }
    })
}

module.exports.help = {
    name: "deposit",
    aliases: []
}