const Discord = require("discord.js");
const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");


//Connect to Database
mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});


//MODELS
const Data = require("../models/data.js");


module.exports.run = async (bot, message, args) => {

    if(message.author.id != "203025242753335296") return message.reply("bot owner only bozo");

    Data.find({
        
        __v: 0
    }).sort([
        [`money`, `descending`]
    ]).exec((err, res) => {
        if(err) console.log(err);

        if(!res) return message.reply("No users found!");

        for(i=0; i < res.length; i++) {
            Data.findOne({
                userID: res[i].userID
            }, (err, data) => {
                if(err) console.log(err)
                if(data) {
                    data.daily = ("0");
                    data.save().catch(err => console.log(err));
                }
            })
        }
        let embedd = new Discord.MessageEmbed();
        
        embedd.setTitle(`Admin reset everyone!`)
        return message.channel.send({ embeds: [embedd] })
    })

}    
module.exports.help = {
    name: "resetdailies",
    aliases: []
}