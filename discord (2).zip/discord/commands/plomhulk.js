const botconfig = require("../botconfig.json");
const Discord = require("discord.js");


module.exports.run = async (client, message, args) => {

    let pedo= ["hello tanisha gaming", "i love you tanisha", "jaz marry me", "i am a pedo", "my nappy is like a nuclear bomb", "do you hate me?", "will you love me?", "why do you hate me?", "HELLLLLLOOOOOOOOO????", "i just shit my pants", "my nappy wappy is very full", "jaz i love you", "You whant to be in a vc?", "I AM PLOMHULK *RRRRRRRRRROOOOOOOOOOOOOAAAAAAAAAAAAAAAARRRRRRRRR*", "do you whant to play valorant?", "can you stream?", "can you turn on your cam?", "can you stroke for me?"];
    var pick = pedo[Math.floor(Math.random() * pedo.length)];
    message.channel.send(pick)
    .then(async m => {
        setTimeout(() => message.delete(), 5000)
        setTimeout(() => m.delete(), 5000)
      });

}


module.exports.help = {
    name: "plomholt",
    aliases: ["pedo", "plom", "tanishalover", "nonce", "pedophile", "kiddyfiddler", "jazlover", "plomhulk"]
}