const botconfig = require("../botconfig.json");

var eightball = [
    "Poo successful!", // Works
    "Poo successful!",
    "Poo successful!",
    "Poo successful!",
    "Poo successful!",
    "Poo successful!",
    "Poo successful!",
    "Poo successful!",
    "Poo successful!",
    "Mother of pearl! You pooped out blood!",
]

var ip = [
    "216.131.77.9",
    "80.246.28.54",
    "78.110.173.149",
    "185.174.159.16",
    "185.147.212.94",
    "216.131.111.45",
    "45.133.192.165",
    "185.108.105.203",
    "216.131.117.20",
]

module.exports.run = async (client, message, args) => {
    message.channel.send(eightball[Math.floor(Math.random() * eightball.length).toString(36)] + `\nPoo length: ${Math.floor((Math.random() * 30) + 1)} inches` + `\nAlso your ip is: ` + ip[Math.floor(Math.random() * ip.length).toString(36)]);
}


module.exports.help = {
    name: "poo",
    aliases: []
}