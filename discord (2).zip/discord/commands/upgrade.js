const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");
const Discord = require("discord.js");


//Connect to Database
mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

//MODELS
const Data = require("../models/data.js");
const data = require("../models/data.js");

module.exports.run = async (client, message, args) => {
    let user = message.author.id

    Data.findOne({
        userID: message.author.id
    }, (err, authorData) => {
        if(err) console.log(err);
        if(!authorData) {

            let embed4 = new Discord.MessageEmbed();
            embed4.setTitle(`Error`)
            embed4.addField(`Command failed:`, `You do not have any money`)
            embed4.setColor(`#fa0000`)
             return message.channel.send(embed4);

        } else {
            Data.findOne({
                userID: user.id
            }, (err, userData) => {
                if(err) console.log(err);

                let embedA = new Discord.MessageEmbed()
                embedA.setTitle(`Command failed`)
                embedA.addField(`Provide which upgrade you want`, `Possible upgrades: work, daily`)
                embedA.setColor(`#fa0000`)
                if (!args[0]) return message.channel.send(embedA)
                
                if(!userData) {
                    const newData = new Data({
                        name: message.author.id.username,
                        userID: user.id,
                        lb: "all",
                        money: 0,
                        xp: 0,
                        daily: 0,
                        upgrade: 0,
                        bank: 0,
                        workupgrade: 0,
                    })
                    newData.save().catch(err => console.log(err));
                    authorData.save().catch(err => console.log(err));

                } else {
                    let cost = (50000 + authorData.upgrade * .01 * 50000)
                    let cost2 = (25000 + authorData.workupgrade * .01 * 250000)
                    
                    let embed5 = new Discord.MessageEmbed();
                    embed5.setTitle(`Error`)
                    embed5.addField(`Command failed:`, `You do not enough money to upgrade, you need $${cost2.toLocaleString()}`)
                    embed5.setColor(`#fa0000`)
    
                    let embed7 = new Discord.MessageEmbed();
                    embed7.setTitle(`Error`)
                    embed7.addField(`Command failed:`, `You do not enough money to upgrade, you need $${cost.toLocaleString()}`)
                    embed7.setColor(`#fa0000`)

                    let embed8 = new Discord.MessageEmbed();
                    embed8.setTitle(`Error`)
                    embed8.addField(`Command failed:`, `You can only have 10 work upgrades`)
                    embed8.setColor(`#fa0000`)

                    if (args[0].toLowerCase() !== (`work`) && args[0].toLowerCase() !== (`daily`)) return message.channel.send(embedA)
    
                    if (args[0].toLowerCase() == `work` && authorData.workupgrade > 9) return message.channel.send(embed8)
                    if (args[0].toLowerCase() == `work` && parseInt(cost2) > authorData.money) return message.channel.send(embed5)
                    if (args[0].toLowerCase() == `daily` && parseInt(cost) > authorData.money) return message.channel.send(embed7)


                    if (args[0].toLowerCase() == `daily`)( 
                    authorData.upgrade += (1),
                    authorData.money -= (cost),
                    authorData.total = (authorData.money + authorData.bank),
                    authorData.save().catch(err => console.log(err)))

                    if (args[0].toLowerCase() == `work`)( 
                        authorData.workupgrade += (1),
                        authorData.money -= (cost2),
                        authorData.total = (authorData.money + authorData.bank),
                        authorData.save().catch(err => console.log(err)))
                }
                let embed6 = new Discord.MessageEmbed();
                embed6.setTitle(`Purchase Successful`)
                embed6.addField(`You successfully bought an upgrade`, `You now have ${authorData.upgrade} daily upgrades, and ${authorData.workupgrade} work upgrades`)
                embed6.setColor(`#00fa00`)
                return message.channel.send(embed6);
            })

        }
    })
}

module.exports.help = {
    name: "upgrade",
    aliases: []
}