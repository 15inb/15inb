const Discord = require("discord.js");
module.exports.run = async (client, message, args) => {

if(message.author.id != "395646231524671498") return message.reply("FART! NO!");

message.channel.send(`https://cdn.discordapp.com/attachments/979896821302304809/981386282276102184/IMG_4971.png?size=4096`)

}


module.exports.help = {
    name: "bonk",
    aliases: []
}