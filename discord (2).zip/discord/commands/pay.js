const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");
const Discord = require("discord.js");


//Connect to Database
mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

//MODELS
const Data = require("../models/data.js");

module.exports.run = async (client, message, args) => {

    let user = message.mentions.members.first() || client.users.cache.get(args[0]);
    if(!user) return message.reply("Sorry, couldn't find that user.");

    if(user.id === message.author.id) return message.reply("why tf u paying yourself");
    if (args[1] == "all") return message.reply ("You can only enter whole numbers.")

    Data.findOne({
        userID: message.author.id
    }, (err, authorData) => {
        if(err) console.log(err);
        if(!authorData) {
            return message.reply("You don't have any money to send.");
        } else {
            Data.findOne({
                userID: user.id
            }, (err, userData) => {
                if(err) console.log(err);

                if(!args[1]) return message.reply("Please specify the amount you want to pay.");

                if(parseInt(args[1]) > authorData.money) return message.reply("You do not have that much money.");
                if(parseInt(args[1]) < 1) return message.reply("You cannot pay less than $1.");
               
                try {
                    var payamount = parseFloat(args[1]);
                } catch {
                    return message.reply("You can only enter whole numbers.");
                }

                if(!userData) {
                    const newData = new Data({
                        name: client.users.cache.get(user.id).username,
                        userID: user.id,
                        lb: "all",
                        money: parseInt(args[1]),
                        xp: 0,
                        daily: 0,
                        upgrade: 1,
                        bank: 0,
                    })
                    authorData.money -= parseInt(args[1]);
                    authorData.total = (authorData.money + authorData.bank)
                    newData.save().catch(err => console.log(err));
                    authorData.save().catch(err => console.log(err));

                } else {

                    userData.money += parseInt(payamount);
                    authorData.money -= parseInt(payamount);
                    userData.total = (userData.money + userData.bank)
                    authorData.total = (authorData.money + authorData.bank)
                    userData.save().catch(err => console.log(err));
                    authorData.save().catch(err => console.log(err));
                }
                let fix = args[1]
                return message.channel.send(`${message.author.username} paid $${fix.toLocaleString()} to ${client.users.cache.get(user.id).username}`);
            })

        }
    })
}

module.exports.help = {
    name: "pay",
    aliases: []
}