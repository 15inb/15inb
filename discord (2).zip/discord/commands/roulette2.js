const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");
const Discord = require("discord.js");


//Connect to Database
mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

//MODELS
const Data = require("../models/data.js");

module.exports.run = async (bot, message, args) => {

    if (message.author.id != ("203025242753335296")) return message.reply("Command in development");
    
    Data.findOne({
        userID: message.author.id
    }, (err, data) => {
        if(err) console.log(err);
        if(!data) {
            const newData = new Data({
                name: message.author.username,
                userID: message.author.id,
                lb: "all",
                money: 0,
                xp: 0,
                daily: 0,
                upgrade: 1,
                bank: 0,
            })
            newData.save().catch(err => console.log(err));
            let embed4 = new Discord.MessageEmbed();
            embed4.setTitle(`Error`)
            embed4.addField(`Command failed:`, `You do not have any money to gamble with`)
            embed4.setColor(`#fa0000`)

            return message.channel.send(embed4);
        } else {
            let embed4 = new Discord.MessageEmbed();
            embed4.setTitle(`Error`)
            embed4.addField(`Command failed:`, `You do not have any money to gamble with`)
            embed4.setColor(`#fa0000`)

            if(data.money <=0) return message.channel.send(embed4);

            let embed5 = new Discord.MessageEmbed();
            embed5.setTitle(`Error`)
            embed5.addField(`Command failed:`, `Please either specify a number from 0 to 36, or a color(red, black, or green)`)
            embed5.setColor(`#fa0000`)

            if(!args[0]) return message.channel.send(embed5);


            let embed7 = new Discord.MessageEmbed();
            embed7.setTitle(`Error`)
            embed7.addField(`Command failed:`, `Specify how much money you wish to bet`)
            embed7.setColor(`#fa0000`)

            if(!args[1]) return message.channel.send(embed7);

            if(args[1].toLowerCase() == "all") args[1] = data.money;

            let embed8 = new Discord.MessageEmbed();
            embed8.setTitle(`Error`)
            embed8.addField(`Command failed:`, `You can not bet negative amounts`)
            embed8.setColor(`#fa0000`)

            if(args[0] < 0) return message.channel.send(embed8)

            if(isNaN(args[0])) {

                let embed6 = new Discord.MessageEmbed();
                embed6.setTitle(`Error`)
                embed6.addField(`Command failed:`, `Specify either a number between 0 and 36, or a color(Color specified must be red, or black)`)
                embed6.setColor(`#fa0000`)

                let bet = args[1]
                let win = bet
                let chances = ["red", "black"]
                var pick = chances[Math.floor(Math.random() * chances.length)];

                let embed10 = new Discord.MessageEmbed();
                embed10.setTitle(`Error`)
                embed10.addField(`Command failed:`, `You do not have $${bet.toLocaleString}`)
                embed10.setColor(`#fa0000`)
                if(args[1] > data.money) return message.channel.send(embed10) // checks to see if they have the money they are betting


                if(pick == args[0]) {
                    data.save().catch(err => console.log(err));
                    data.money += +bet
                    data.total = (data.money + data.bank)

                    let embed11 = new Discord.MessageEmbed();
                    embed11.setTitle(`Bot rolled ${pick}`)
                    embed11.addField(`You won $${win.toLocaleString()}`, `New Balance: $${data.money.toLocaleString()} `)
                    embed11.setColor(`#00fa00`)
                    return message.channel.send(embed11)
                } else {
                    data.save().catch(err => console.log(err));
                    data.money += -bet
                    data.total = (data.money + data.bank)

                    let embed12 = new Discord.MessageEmbed();
                    embed12.setTitle(`Bot rolled ${pick}`)
                    embed12.addField(`You lost $${bet.toLocaleString()}`, `New Balance: $${data.money.toLocaleString()} `)
                    embed12.setColor(`#fa0000`)
                    return message.channel.send(embed12);
                }
            }
            
            if(!isNaN(args[0])){

                let embed6 = new Discord.MessageEmbed();
                embed6.setTitle(`Error`)
                embed6.addField(`Command failed:`, `Specify either a number between 0 and 36, or the color red, or black`)
                embed6.setColor(`#fa0000`)
    
                if(args[0] > 36 || args[0] < 0) return message.channel.send(embed6)

            let embed9 = new Discord.MessageEmbed();
            embed9.setTitle(`Error`)
            embed9.addField(`Command failed:`, `You can only enter whole numbers`)
            embed9.setColor(`#fa0000`)

            try {
                var bet = parseFloat(args[1]);
            } catch {
                return message.channel.send(embed9);
            }

            if(bet != Math.floor(bet)) return message.channel.send(embed10);

            let embed10 = new Discord.MessageEmbed();
            embed10.setTitle(`Error`)
            embed10.addField(`Command failed:`, `You do not have $${bet.toLocaleString}`)
            embed10.setColor(`#fa0000`)


            if(data.money < bet) return message.channel.send(embed9);


            let chances= ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36"];
            var pick = chances[Math.floor(Math.random() * chances.length)];

            if(pick == args[0]) {
                let win = bet*36
                data.money += bet*36;
                data.save().catch(err => console.log(err));
                data.total = (data.money + data.bank)
                let embed11 = new Discord.MessageEmbed();
                embed11.setTitle(`Bot rolled ${pick}`)
                embed11.addField(`You won $${win.toLocaleString()}`, `New Balance: $${data.money.toLocaleString()} `)
                embed11.setColor(`#00fa00`)
                return message.channel.send(embed11)
            } else {
                data.money -= bet;
                data.save().catch(err => console.log(err));
                data.total = (data.money + data.bank)
                let embed12 = new Discord.MessageEmbed();
                embed12.setTitle(`Bot rolled ${pick}`)
                embed12.addField(`You lost $${bet.toLocaleString()}`, `New Balance: $${data.money.toLocaleString()} `)
                embed12.setColor(`#fa0000`)
                return message.channel.send(embed12);
            }
       } }
    })
}

module.exports.help = {
    name: "roulette2",
    aliases: []
}