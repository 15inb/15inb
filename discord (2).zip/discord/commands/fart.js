const botconfig = require("../botconfig.json");

var eightball = [
    "Fart successful!", // Works
    "Fart successful!",
    "Fart successful!",
    "Fart successful!",
    "Fart successful!",
    "Fart successful!",
    "Fart successful!",
    "Fart successful!",
    "Fart successful!",
    "Poo successful",
]

module.exports.run = async (client, message, args) => {
    message.channel.send(eightball[Math.floor(Math.random() * eightball.length).toString(36)]);
}


module.exports.help = {
    name: "fart",
    aliases: []
}