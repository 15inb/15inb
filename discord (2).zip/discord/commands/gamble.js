const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");
const talkedRecently = new Set();
const Discord = require("discord.js");


//Connect to Database
mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

//MODELS
const Data = require("../models/data.js");

module.exports.run = async (bot, message, args) => {
    let embed = new Discord.MessageEmbed()
    embed.setTitle(`Command removed`)
    embed.addField(`This command has been removed, please use >roulette`, `This command can now be done if you do >roulette red/black <amount you wish to bet>`)
message.channel.send(embed)
}

module.exports.help = {
    name: "gamble",
    aliases: []
}