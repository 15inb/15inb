const Discord = require("discord.js");

module.exports.run = async (client, message, args, cmd) => {

    let embed = new Discord.MessageEmbed();
    embed.setTitle("**General Commands**")
    embed.addField(">ping", "Checks the bot\'s ping")
    embed.addField(">kiss", "Ping someone to kiss them or don't tag anyone to request a kiss!")
    embed.addField(">cat | >pussy", "Shows a random cat picture")
    embed.addField(">catfacts | >pussyfacts", "Gives a random cat fact")
    embed.addField(">dog", "Shows a random dog picture")
    embed.addField(">dogfact | >dogfacts", "Gives a random dog fact")
    embed.addField(">poo", "Checks your poo")
    embed.addField(">fart", "Checks your fart")
    embed.setColor(`#a91993`)

    let embed2 = new Discord.MessageEmbed()
    embed2.setTitle("**Bank Commands**")
    embed2.addField(">balance | >bal", "Shows how much money you have")
    embed2.addField(">daily", "Can claim daily for an extra bit of money")
    embed2.addField(">leaderboard | >lb", "Shows you the people with the most money")
    embed2.addField(">pay", "Allows you to send money to another player")
    embed2.addField(">gamble", "Coinflip, 50/50 chance to either double your money or lose it")
    embed2.addField(">roulette", "Pick a number from 0-36 for a chance to get massive profits")
    embed2.addField(">work", "Extra bit of money every 5 minutes")
    embed2.addField(">upgrade", "Lets you buy 1 upgrade to increase the amount you get from your daily")
    embed2.addField(">upgrades", "Checks how many upgrades you have")
    embed2.addField(">deposit", "Lets you deposit money into your bank account")
    embed2.addField(">withdraw", "Lets you withdraw money from your bank account")
    embed2.setColor(`#a91993`)

    let embed3 = new Discord.MessageEmbed()
    embed3.setTitle("**Help Menu**")
    embed3.addField("General Commands", "Usage: >help general")
    embed3.addField("Gambling Commands", "Usage: >help gambling")
    embed3.setColor(`#a91993`)

    let embed4 = new Discord.MessageEmbed()
    embed4.setTitle(`**Wasteland Commands**`)
    embed4.addField(`>ticket`, `Creates a ticket`)
    embed4.addField(`>poll`, `Creates a poll, the question MUST have a question mark. Example: >poll Do you want a soda poppy? \"Yes\" \"No\"`)
    embed4.addField(`>archive | >close | >closeticket`, `Archives a ticket, must be typed in the channel of the ticket you want archived`)
    embed4.addField(`>delete | >del`, `Deletes a ticket, must be typed in the channel of the ticket you want deleted`)
    embed4.setColor(`#a91993`)

    if (cmd == "help") {
        if(args[0] == "general") return message.channel.send(embed);
        if(args[0] == "gambling") return message.channel.send(embed2);
        if(args[0] == "wasteland" || args[0] == "wastelands") return message.channel.send(embed4)
        if(!args[0]) return message.channel.send(embed3);

    
    }

}


module.exports.help = {
    name: "help",
    aliases: []
}