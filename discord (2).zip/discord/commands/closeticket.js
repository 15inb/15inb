const Discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

    // ID from the catogory channel tickets.
    const categoryId = "644626077704257546";

    // Get username
    var userName = message.author.username;
    // Verkrijg discriminator
    var userDiscriminator = message.author.discriminator;

    let reason = args.slice(0).join(" ");

    if (message.member.roles.cache.some(role => role.name === 'Staff Team') && !reason) return message.channel.send(`Please provide a reason why you're deleting this ticket.`)

    if (message.guild.id !==(`979892448899788830`)) return

    let embed = new Discord.MessageEmbed()
    embed.setTitle(`Command failed`)
    embed.setFooter(`You may only use this command for tickets`)

    let embed2 = new Discord.MessageEmbed()
    embed2.setTitle(`Command failed`)
    embed2.setFooter(`You may only use this command if you are staff, or if you are using it for your own ticket.`)

    if(message.channel.parent.id !== `979925186268766279`) return message.channel.send(embed);
    if(message.member.roles.cache.some(role => role.name === 'Staff Team') || message.channel.name == message.author.id){

    bot.users.cache.get(`${message.channel.name}`).send(`Your ticket has been archived by ${message.author} with the reason ${reason}`)
    bot.channels.cache.get('979956782371856395').send(`Ticket ${message.channel.name} has been archived by ${message.author} with the reason ${reason}`)
    message.channel.send(`This ticket has been archived. It can be deleted with >delete or >deleteticket\nYou can unarchive it by typing >open ${message.channel.name}`)

    message.channel.updateOverwrite(message.channel.name,{
        VIEW_CHANNEL: false, SEND_MESSAGES: false, ATTACH_FILES: false, ADD_REACTIONS: false
    })

    message.channel.setName(`archived-${message.channel.name}`)

    } else {
        message.channel.send(embed2)
    }
}

module.exports.help = {
    name: "close",
    aliases: ["closeticket", "archive", "archiveticket"]
}