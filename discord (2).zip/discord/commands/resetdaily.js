const Discord = require("discord.js");
const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");


//Connect to Database
mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});


//MODELS
const Data = require("../models/data.js");

module.exports.run = async (client, message, args) => {

    if (message.author.id != ("203025242753335296")) return message.reply("You can't reset dailies");

    let user = message.mentions.members.first() || client.users.cache.get(args[0]);
    if (!user) return message.reply("Sorry, couldn't find that user.");

    Data.findOne({
        userID: user.id
    }, (err, userData) => {
        if (err) console.log(err);

        if (!userData) {
            const newData = new Data({
                name: client.users.cache.get(user.id).username,
                userID: user.id,
                lb: "all",
                money: parseInt(args[1]),
                xp: 0,
                daily: 0,
            })
            newData.save().catch(err => console.log(err));
        } else {
            userData.daily = ("0");
            userData.save().catch(err => console.log(err));
        }
        let embedd = new Discord.MessageEmbed();
        embedd.setTitle(`${message.author.username} reset ${client.users.cache.get(user.id).username}\'s daily cooldown`)
        return message.channel.send(embedd);

    })

}

module.exports.help = {
    name: "resetdaily",
    aliases: ["rd"]
}