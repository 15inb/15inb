const prettyMilliseconds = require('pretty-ms');
const Discord = require("discord.js");
const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");

//Connect to Database
mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

//MODELS
const Data = require("../models/data.js");

module.exports.run = async (bot, message, args) => {
    let timeout = 86400000;


    Data.findOne({
        userID: message.author.id
    }, (err, data) => {
        if(err) console.log(err);
        if(!data) {
            const newData = new Data({
                name: message.author.username,
                userID: message.author.id,
                KazanirBet: 0,
                KaybederBet: 0,
                compulsory: 3,
                lb: "all",
                money: 0,
                xp: 0,
                daily: 0,
                upgrade: 1,
                bank: 0,
                total: 0,
                workupgrade: 0,
            })
            newData.save().catch(err => console.log(err));
            return message.channel.send('ERROR: COMMAND FAILED. RETRY COMMAND.')
        } else {

            if(timeout - (Date.now() - data.daily) > 0) {
                let time = timeout - (Date.now() - data.daily)
                let cooldown = prettyMilliseconds(time, {secondsDecimalDigits: 0});

                let cooldownembed = new Discord.MessageEmbed();
                cooldownembed.setTitle(`Command Failed`)
                cooldownembed.addField(`Daily already collected`, `You can collect again in ${cooldown}`)
                cooldownembed.setColor(`#fa0000`)
                return message.channel.send(cooldownembed)

            } else {
                let reward = (10000+data.upgrade*.25 * 10000)
                data.money += (reward);
                data.total = (data.money+data.bank)
                data.daily = Date.now();
                data.save().catch(err => console.log(err));

                let dailyembed = new Discord.MessageEmbed();
                dailyembed.setTitle(`Reward Received`)
                dailyembed.addField(`Daily reward received:`, `$${reward.toLocaleString()}`)
                dailyembed.addField(`New balance:`, `$${data.money.toLocaleString()}`)
                dailyembed.setColor(`#fa0000`)

                message.channel.send(dailyembed);
                let interest = Math.round(data.bank*.15)
                let interest2 = Math.round(data.bank*.10)
                let interest3 = Math.round(data.bank*.05)
                let interest4 = Math.round(data.bank*.025)
                let interest5 = Math.round(data.bank*.01)


                if(data.bank>10000000) return ( data.bank += interest5, data.total = (data.money + data.bank)  )
                if(data.bank>5000000) return ( data.bank += interest4, data.total = (data.money + data.bank)  )
                if(data.bank>2500000) return ( data.bank += interest3, data.total = (data.money + data.bank)  )
                if(data.bank>1000000) return ( data.bank += interest2, data.total = (data.money + data.bank)  )
                if(data.bank>100000) return ( data.bank += interest, data.total = (data.money + data.bank)  )
            }  
        }
    }) 
}

module.exports.help = {
    name: "daily",
    aliases: ["day"]
}