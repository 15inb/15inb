const botconfig = require("../botconfig.json");
const { Multi } = require("discord-simple-multipurpose");
const something = new Multi();

module.exports.run = async (client, message, args) => {
let catfact = await something.fetchCatFact()
    message.channel.send(catfact)

}


module.exports.help = {
    name: "catfact",
    aliases: ["pussyfact"]
}