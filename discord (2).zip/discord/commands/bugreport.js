const Discord = require("discord.js");


module.exports.run = async (client, message, args) => {


    let embed4 = new Discord.MessageEmbed();
    embed4.setTitle(`Error`)
    embed4.addField(`Command failed`, `No report specified`)
    embed4.setColor(`#fa0000`)
    let report = args.slice(0).join(" ");
    if (!report) return message.channel.send(embed4)

    let embed = new Discord.MessageEmbed();
    embed.setTitle(`Bug report`)
    embed.addField(`${report}`, `Sent by ${message.member} / ${message.member.id}`)
    embed.setColor(`#38ff45`)
    let embed2 = new Discord.MessageEmbed()
    embed2.setTitle(`Report successfull`)
    embed2.addField(`Your report has successfully been sent in`, `Abuse of this command will result in a blacklist from the bot.`)
    embed2.setColor(`#38ff45`)
    message.channel.send(embed2)
    client.channels.cache.get('544305912236474392').send(embed)

}

module.exports.help = {
    name: "bugreport",
    aliases: [`report`]
}
