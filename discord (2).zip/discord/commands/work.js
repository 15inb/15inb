const prettyMilliseconds = require('pretty-ms');
const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");
const talkedRecently = new Set();
const Discord = require("discord.js")
const { MessageEmbed } = require('discord.js');

//Connect to Database
mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

//MODELS
const Data = require("../models/data.js");
const data = require('../models/data.js');

module.exports.run = async (bot, message, args) => {

    let timeout = 300000;
    let reward = Math.floor((Math.random() * 7500) + 1);

    Data.findOne({
        userID: message.author.id
    }, (err, data) => {
        if(err) console.log(err);
        if(!data) {
            const newData = new Data({
                name: message.author.username,
                userID: message.author.id,
                KazanirBet: 0,
                KaybederBet: 0,
                compulsory: 3,
                lb: "all",
                money: reward,
                xp: 0,
                work: 0,
                upgrade: 1,
                bank: 0,
                workupgrade: 0,
            })
            newData.save().catch(err => console.log(err));
            return message.channel.send(`${message.author.username} has $${reward}.`);
        } else {
            if((timeout-(15000 * data.workupgrade)) - (Date.now() - data.work) > 0) {
                let time = (timeout-(15000 * data.workupgrade)) - (Date.now() - data.work)
                let cooldown = prettyMilliseconds(time, {secondsDecimalDigits: 0});
                let cooldownembed = new Discord.MessageEmbed();
                cooldownembed.setTitle(`Command Failed`)
                cooldownembed.addField(`You're tired!`, `You can work again in ${cooldown}`)
                cooldownembed.setColor(`#fa0000`)
                return message.channel.send(cooldownembed);
            } else {
                data.money += reward;
                data.total = (data.money + data.bank)
                data.work = Date.now()
                data.save().catch(err => console.log(err));

                let embed = new Discord.MessageEmbed()
                embed.setTitle(`Work`)
                embed.addField(`You worked and recieved $${reward.toLocaleString()}`, `You now have $${data.money.toLocaleString()} in your wallet`)
                embed.setColor(`#13ec37`)

                return message.channel.send(embed);
            }  
        }
    }) 
}

module.exports.help = {
    name: "work",
    aliases: ["slave"]
}