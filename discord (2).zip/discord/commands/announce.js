const Discord = require("discord.js");


module.exports.run = async (client, message, args) => {

    let embed2 = new Discord.MessageEmbed();
    embed2.setTitle(`Error`)
    embed2.addField(`Command failed`, `Missing permission MANAGE_MESSAGES`)
    embed2.setColor(`#fa0000`)
    if(!message.member.hasPermission('MANAGE_MESSAGES')) {
        message.channel.send(embed);
        return;
    };

    let embed4 = new Discord.MessageEmbed();
    embed4.setTitle(`Error`)
    embed4.addField(`Command failed`, `No announcement specified`)
    embed4.setColor(`#fa0000`)
    let announcement = args.slice(0).join(" ");
    if (!announcement) return message.channel.send(embed4)

    let embed = new Discord.MessageEmbed();
    embed.setTitle(`Discord Announcement`)
    embed.addField(`${announcement}`, `Sent by ${message.member}`)
    embed.setColor(`#38ff45`)

    const announcementChannel = message.guild.channels.cache.find(ch => ch.name ==="announcements");
    let embed3 = new Discord.MessageEmbed();
    embed3.setTitle(`Error`)
    embed3.addField(`Command Failed`, `Missing #announcements channel`)
    embed3.setColor(`#fa0000`)
    message.delete()
    if (!announcementChannel) return message.channel.send(embed3)
    announcementChannel.send(embed)

}

module.exports.help = {
    name: "announce",
    aliases: [`announcement`]
}
