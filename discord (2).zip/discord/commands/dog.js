const botconfig = require("../botconfig.json");
const axios = require("axios");


module.exports.run = async (client, message, args) => {

    const dog = await axios.get("https://api.thedogapi.com/v1/images/search")
        .catch((err) => {
            console.error("ERR", err)
        })

    message.channel.send(dog.data[0].url)

}


module.exports.help = {
    name: "dog",
    aliases: ["hazel"]
}