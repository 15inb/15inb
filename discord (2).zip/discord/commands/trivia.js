const botconfig = require("../botconfig.json");
const fetch = require('node-fetch')


module.exports.run = async (client, message, args) => {
    if (message.author.id != ("203025242753335296")) return message.reply("Command in development");
    const response = await fetch('https://opentdb.com/api.php?amount=5&category=9&difficulty=easy&type=boolean')
    const data = await response.json();
    var length = data.results.length;
    var randomNumber = Math.floor(Math.random() * length);
    var randomQuestion = data.results[randomNumber];
    var question = randomQuestion.question;
    var correctAnswer = randomQuestion.correct_answer;

    message.channel.send(question);
    const filter = m => m.author.id === message.author.id;
    const answer = await message.channel.awaitMessages(filter, { maxMatches: 1, time:10000, errors: ['time', 'maxMatches']}).catch((err) => { console.error(err); });
    if (answer === correctAnswer)
    {
        message.channel.send("You got the answer right!");
    } else {
        message.channel.send("That is incorrect.");
    }
}


module.exports.help = {
    name: "trivia",
    aliases: []
}
 


// https://opentdb.com/api.php?amount=1&category=9&difficulty=easy