const botconfig = require("../botconfig.json");
const axios = require("axios");


module.exports.run = async (client, message, args) => {


    const cat = await axios.get("https://api.thecatapi.com/v1/images/search")
        .catch((err) => {
            console.error("ERR", err)
        })

    message.channel.send(cat.data[0].url)
    .then(async m => {
        m.react(`1️⃣`);
        m.react(`2️⃣`);
        m.react(`3️⃣`);
        m.react(`4️⃣`);
        m.react(`5️⃣`);
      });

}


module.exports.help = {
    name: "cat",
    aliases: ["pussy", "callie", "lilo", "loki"]
}