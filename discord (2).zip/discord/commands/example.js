const Discord = require("discord.js");
const colors = require("../color.json");


module.exports.run = async (client, message, args) => {

    let embed = new Discord.MessageEmbed();

    embed.setTitle(`Bari Zardan Düşseydik`);
    embed.setColor(colors.black);
    embed.setDescription(`EkremAbi`);
    embed.addField("_ _", "Field Two");
    embed.addField("_ _", "Field Two");
    embed.setImage("https://pbs.twimg.com/media/EWMMqw9UYAEQsr0.png");
    embed.setThumbnail("");
    embed.setFooter("");
    message.channel.send(embed)

}

module.exports.help = {
    name: "example",
    aliases: []
}
