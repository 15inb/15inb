const Discord = require("discord.js");


module.exports.run = async (client, message, args) => {


    let embed4 = new Discord.MessageEmbed();
    embed4.setTitle(`Error`)
    embed4.addField(`Command failed`, `No suggestion specified`)
    embed4.setColor(`#fa0000`)
    let report = args.slice(0).join(" ");
    if (!report) return message.channel.send(embed4)

    let embed = new Discord.MessageEmbed();
    embed.setTitle(`Suggestion`)
    embed.addField(`${report}`, `Sent by ${message.member} / ${message.member.id}`)
    embed.setColor(`#38ff45`)
    let embed2 = new Discord.MessageEmbed()
    embed2.setTitle(`Suggestion successfull`)
    embed2.addField(`Your suggestion has successfully been sent in`, `Abuse of this command will result in a blacklist from the bot.`)
    embed2.setColor(`#38ff45`)
    message.channel.send(embed2)
    client.channels.cache.get('979861559591469107').send(embed)

}

module.exports.help = {
    name: "suggest",
    aliases: [`suggestion`]
}
