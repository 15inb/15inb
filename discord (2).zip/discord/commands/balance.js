const Discord = require("discord.js");
const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");


//Connect to Database
mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})

//MODELS
const Data = require("../models/data.js");


module.exports.run = async (client, message, args) => {


    if (!args[0]) {
        var user = message.author;
    } else {
        var user = message.mentions.users.first() || client.users.cache.get(args[0])

        let embed2 = new Discord.MessageEmbed();
        embed2.setTitle(`Error`)
        embed2.addField(`Command failed:`, `Failed to find user`)
        embed2.setColor(`#fa0000`)
        if (!user) return message.reply(embed2);
    }

    Data.findOne({
        userID: user.id
    }, (err, data) => {
        if (err) console.log(err);
        if (!data) {
            const newData = new Data({
                name: client.users.cache.get(user.id).username,
                userID: client.users.cache.get(user.id).id,
                KazanirBet: 0,
                KaybederBet: 0,
                zorunlu: 3,
                lb: "all",
                money: 0,
                xp: 0,
                daily: 0,
                bank: 0,

            })
            newData.save().catch(err => console.log(err));
            let embed2 = new Discord.MessageEmbed();
            embed2.setTitle(`${client.users.cache.get(user.id).username}\'s money`)
            embed2.addField(`Wallet:`, `$0`)
            embed2.addField(`Bank account:`, `$0`)
            embed2.addField(`Total:`, `$0`)
            embed2.setColor(`#9c3eef`)
            return message.channel.send(embed2);
        } else {
            let embed = new Discord.MessageEmbed();
            embed.setTitle(`${data.name}\'s money`)
            embed.addField(`Wallet:`, `$${data.money.toLocaleString()}`)
            embed.addField(`Bank account:`, `$${data.bank.toLocaleString()}`)
            embed.addField(`Total:`, `$${data.total.toLocaleString()}`)
            embed.setColor(`#9c3eef`)
            return message.channel.send(embed);
        }
    })

}

module.exports.help = {
    name: "balance",
    aliases: ["bal"]
}