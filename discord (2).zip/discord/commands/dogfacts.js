const botconfig = require("../botconfig.json");
const { Multi } = require("discord-simple-multipurpose");
const something = new Multi();

module.exports.run = async (client, message, args) => {
let dogfact = await something.fetchDogFact()
    message.channel.send(dogfact)

}


module.exports.help = {
    name: "dogfact",
    aliases: ['dogfacts']
}