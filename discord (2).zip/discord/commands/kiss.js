const Discord = require("discord.js");
const colors = require("../color.json");

module.exports.run = async (client, message, args) => {

    let gifs = [
        "https://citythatbreeds.com/blog/wp-content/uploads/2011/12/KISSOHGOOOOOD.gif",
        "https://j.gifs.com/PNoWx6.gif",
        "https://i.pinimg.com/originals/01/fb/2c/01fb2cb2cf0855514cf1df69f46acda8.gif",
    ];

    let pick = gifs[Math.floor(Math.random() * gifs.length)];
    let embed = new Discord.MessageEmbed();
    let embedd = new Discord.MessageEmbed();
    let embeddd = new Discord.MessageEmbed();


    embedd.setColor(colors.red);
    embed.setImage(pick);


    if (!args[0]) {
        var user = message.author;
    } else {
        var user = message.mentions.users.first() || client.users.cache.get(args[0])
        if (!user) return message.reply("Sorry, couldn't find that user.");

    }


    if (args[0]) {

        let user = message.mentions.members.first();

        if (user.id === message.author.id) return embeddd.setImage("https://25yearslatersite.com/wp-content/uploads/2019/07/Predestination-Featured-e1562792296621.jpg"), embeddd.setTitle(`Keep your fantasies to yourself ${message.author.username}!`), message.channel.send(embeddd);

        embed.setTitle(`${message.author.username} kissed ${client.users.cache.get(user.id).username}!`);
        message.channel.send(embed);
    } else {
        embedd.setTitle(`${message.author.username} wants a smooch!`);
        message.channel.send(embedd);
    }


}


module.exports.help = {
    name: "kiss",
    aliases: ["k"]
}