const Discord = require("discord.js");


module.exports.run = async (client, message, args) => {

    let embed2 = new Discord.MessageEmbed();
    embed2.setTitle(`Error`)
    embed2.addField(`Command failed`, `Missing permissions`)
    embed2.setColor(`#fa0000`)
    if(!message.member.hasPermission('MANAGE_MESSAGES')) {
        message.channel.send(embed2);
        return;
    };



    let embed = new Discord.MessageEmbed();
    embed.setTitle(`Bug fix and roulette update`)
    embed.addField(`Fixed >deposit`, `Fixed bug where deposit would reset your money, and made it so you can >deposit all again`)
    embed.addField(`Updated roulette`, `Made it so you can bet on black and red on roulette. Just do >roulette black/red <amount you want bet>`)
    embed.addField(`Removed >gamble`, `Since you can now just do >roulette red/black there is no point to have the gamble command`)
    embed.addField(`Other bug fixes`, `I fixed some other shit too`)
    embed.setColor(`#38ff45`)

    message.delete()
    message.channel.send(embed)

}

module.exports.help = {
    name: "update",
    aliases: []
}
