const Discord = require("discord.js");
const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");


//Connect to Database
mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});


//MODELS
const Data = require("../models/data.js");

module.exports.run = async (client, message, args) => {

    let embed = new Discord.MessageEmbed();
    embed.setTitle(`Error`)
    embed.addField(`Command failed`, `Missing permissions to execute command`)
    embed.setColor(`#fa0000`)


    
    if (message.author.id != ("203025242753335296")) return message.reply(embed);

    let embed2 = new Discord.MessageEmbed();
    embed2.setTitle(`Error`)
    embed2.addField(`Command failed:`, `Failed to find user`)
    embed2.setColor(`#fa0000`)

    let user = message.mentions.members.first() || client.users.cache.get(args[0]);
    if (!user) return message.reply(embed2);

    Data.findOne({
        userID: user.id
    }, (err, userData) => {
        if (err) console.log(err);

        if (!args[1]) return message.reply("Please specify the mount you want to take.");

        if (args[1] != Math.floor(args[1])) return message.reply("Please enter only whole numbers!")


        if (!userData) {
            const newData = new Data({
                name: client.users.cache.get(user.id).username,
                userID: user.id,
                lb: "all",
                money: parseInt(args[1]),
                xp: 0,
                daily: 0,
            })
            newData.save().catch(err => console.log(err));
        } else {
            userData.money -= parseInt(args[1]);
            userData.save().catch(err => console.log(err));
        }
        let embedd = new Discord.MessageEmbed();
        embedd.setTitle(`${message.author.username} took $${args[1]} from ${client.users.cache.get(user.id).username}`)
        return message.channel.send(embedd);

    })

}

module.exports.help = {
    name: "admintake",
    aliases: ["at"]
}