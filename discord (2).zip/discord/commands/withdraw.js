const mongoose = require("mongoose");
const botconfig = require("../botconfig.json");
const Discord = require("discord.js");


//Connect to Database
mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

//MODELS
const Data = require("../models/data.js");

module.exports.run = async (client, message, args) => {

    let embed = new Discord.MessageEmbed();
    embed.setTitle(`Error`)
    embed.addField(`Command failed:`, `Specify the amount you wish to withdraw`)
    embed.setColor(`#fa0000`)

    if(!args[0]) return message.channel.send(embed);

    let user = message.author.id

    Data.findOne({
        userID: message.author.id
    }, (err, authorData) => {
        if(err) console.log(err);
        if(!authorData) {
            return message.reply("You don't have any money to upgrade with.");
        } else {
            Data.findOne({
                userID: user.id
            }, (err, userData) => {
                if(err) console.log(err);

                let embed2 = new Discord.MessageEmbed();
                embed2.setTitle(`Error`)
                embed2.addField(`Command failed:`, `You are unable to withdraw negative amounts`)
                embed2.setColor(`#fa0000`)

                let embed3 = new Discord.MessageEmbed();
                embed3.setTitle(`Error`)
                embed3.addField(`Command failed:`, `You don\'t have $${args[0]} to withdraw`)
                embed3.setColor(`#fa0000`)
                if(parseInt(args[0]) > authorData.bank) return message.channel.send(embed3);
                if(args[0] < 1) return message.channel.send(embed)


                
                if(!userData) {
                    const newData = new Data({
                        name: message.author.id.username,
                        userID: user.id,
                        lb: "all",
                        money: 0,
                        xp: 0,
                        daily: 0,
                        bank: 0,
                    })
                    authorData.money -= (args[0]);
                    newData.save().catch(err => console.log(err));
                    authorData.save().catch(err => console.log(err));

                } else {


                    if(args[0].toLowerCase() == "all") args[0] = authorData.bank;


                    authorData.money += (+args[0]);
                    authorData.bank += (-args[0]);
                    authorData.total = authorData.money + authorData.bank
                    authorData.save().catch(err => console.log(err));
                }
                let fix = args[0]

                let embed = new Discord.MessageEmbed();
                embed.setTitle(`You have withdrew $${fix.toLocaleString()} from your bank`)
                embed.addField(`New Bank Balance:`, `$${authorData.bank.toLocaleString()}`)
                embed.addField(`New Wallet Balance:`, `$${authorData.money.toLocaleString()}`)
                embed.setColor(`#1000c2`)

                return message.channel.send(embed);
            })

        }
    })
}

module.exports.help = {
    name: "withdraw",
    aliases: []
}