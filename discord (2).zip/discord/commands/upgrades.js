const mongoose = require("mongoose");
const Discord = require("discord.js");
const botconfig = require("../botconfig.json");
const prettyMilliseconds = require('pretty-ms');


//Connect to Database
mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

//MODELS
const Data = require("../models/data.js");

module.exports.run = async (client, message) => {
    let user = message.author.id

    Data.findOne({
        userID: message.author.id
    }, (err, authorData) => {
        if(err) console.log(err);
        if(!authorData) {
            let embed4 = new Discord.MessageEmbed();
            embed4.setTitle(`Error`)
            embed4.addField(`Command failed:`, `You are not in the database`)
            embed4.setColor(`#fa0000`)
             return message.channel.send(embed4);
        } else {
            Data.findOne({
                userID: user.id
            }, (err, userData) => {
                if(err) console.log(err);
                let cost = (50000 + authorData.upgrade*.01 * 50000)
                let cost2 = (25000 + authorData.workupgrade * .01 * 100000)
                let embed4 = new Discord.MessageEmbed()
                embed4.setTitle(`Your upgrades`)
                embed4.addField(`Amount of daily upgrade(s)`, `${authorData.upgrade}`)
                let boost = 10000+10000*authorData.upgrade*.25
                embed4.addField(`Total daily amount`, `$${boost.toLocaleString()}`)
                embed4.addField(`Cost of next daily upgrade`, `$${cost.toLocaleString()}`)
                embed4.addField(`Amount of work upgrade(s)`, `${authorData.workupgrade}`)

                let time = (300000-(15000 * authorData.workupgrade))
                let cooldown = prettyMilliseconds(time, {secondsDecimalDigits: 0});

                embed4.addField(`Your current work cooldown`, `${cooldown}`)
                embed4.addField(`Cost of next work upgrade`, `$${cost2.toLocaleString()}`)
                embed4.setColor(`#fa0000`)


                




                let embed5 = new Discord.MessageEmbed()
                embed5.setTitle(`Your upgrades`)
                embed5.addField(`Amount of daily upgrade(s)`, `${authorData.upgrade}`)
                let boost1 = 10000+10000*authorData.upgrade*.25
                embed5.addField(`Total daily amount`, `$${boost1.toLocaleString()}`)
                embed5.addField(`Cost of next daily upgrade`, `$${cost.toLocaleString()}`)
                embed5.addField(`Amount of work upgrade(s)`, `${authorData.workupgrade}`)

                let time1 = (300000-(15000 * authorData.workupgrade))
                let cooldown1 = prettyMilliseconds(time1, {secondsDecimalDigits: 0});

                embed5.addField(`Your current work cooldown`, `${cooldown1}`)
                embed5.addField(`Cost of next work upgrade`, `MAX LEVEL`)
                embed5.setColor(`#fa0000`)

                if(cost2 > 34999) return message.channel.send(embed5)


                if(parseInt('100000000000000') > authorData.upgrade) return message.channel.send(embed4);

                
                if(!userData) {
                    const newData = new Data({
                        name: message.author.id.username,
                        userID: user.id,
                        lb: "all",
                        money: 0,
                        xp: 0,
                        daily: 0,
                        upgrade: 0,
                        bank: 0,
                    })
                    authorData.money -= (cost);
                    newData.save().catch(err => console.log(err));
                    authorData.save().catch(err => console.log(err));

                } else {

                    authorData.upgrade += (1);
                    authorData.money += (-cost);
                    authorData.save().catch(err => console.log(err));
                }

                return message.channel.send(`You bought an upgrade\nYou now have ${authorData.upgrade} upgrades`);
            })

        }
    })
}

module.exports.help = {
    name: "upgrades",
    aliases: []
}