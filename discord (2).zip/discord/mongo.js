const mongoose = require("mongoose")
const mongoPath = "mongodb+srv://15inb:Boarman97@cluster0.71xkc.mongodb.net/gamblingbot?retryWrites=true&w=majority"


module.exports = async () => {
    await mongoose.connect(mongoPath, {
        useNewUrlParser: true,
        useUnifiedTopology: true
    })

    return mongoose
}