
const Discord = require("discord.js");
const { Client, Intents } = require('discord.js');
const bot = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });
const botconfig = require("./botconfig.json");
const mongoose = require("mongoose");
const fs = require("fs");

mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});


bot.commands = new Discord.Collection();
bot.aliases = new Discord.Collection();


// READ COMMANDS FOLDER
fs.readdir("./wastelands/", (err, files) => {
    if (err) console.log(err);

    let jsfile = files.filter(f => f.split(".").pop() === "js");
    if (jsfile.length <= 0) {
        return console.log("No commands found!");
    }

    jsfile.forEach((f) => {
        if (!f.endsWith(".js")) return;
        let props = require(`./wastelands/${f}`);
        console.log(`${f} loaded!`);
        bot.commands.set(props.help.name, props);
        props.help.aliases.forEach(alias => {
            bot.aliases.set(alias, props.help.name);
        })
    })
})

// BOT ONLINE MESSAGE AND ACTIVITY MESSAGE
bot.on("ready", async () => {
    console.log(`${bot.user.username} is online on ${bot.guilds.cache.size} servers!`);
    bot.user.setActivity(`>help`);

})





  bot.on("messageCreate", async message => {

    

    let blacklisted = [`71672`, `fag`, `f@g`, `retard`, `r3tard`, `nig`, `n1g`, `chink`, `beaner`, `beaney`, `bootlip`, `ching chong`, `chinaman`, `chonky`, `coon`, `curry muncher`, `curry-muncher`, `dothead`, `wog`, `w0g`, `jig`, `zigabo`, `kike`, `kyke`, `munt`, `negro`, `neger`, `pak`, `raghead`, `rag head`, `redskin`, `redskin`, `spic`, `spik`, `spig`, `wetback`, `wet back`, `heeb`, `hebe`, `tranny`, `dyke`];
    let foundInText = false;
    for (var i in blacklisted) {
      if (message.content.toLowerCase().includes(blacklisted[i])) foundInText = true;
    }
    if (foundInText) {
        let embed = new Discord.MessageEmbed()
            embed.setTitle(`Blacklisted Word Detected`)
            embed.setColor(`#8614d7`)
            embed.addField(`Author:`, `${message.author}`)
            embed.addField(`Channel:`, `${message.channel.name}`)
            embed.addField(`Message:`,`${message.content}`)

        let embed2 = new Discord.MessageEmbed()
            embed2.setTitle(`Blacklisted Word Detected`)
            embed2.setColor("#8614d7")
            embed2.addField(`Author:`, `${message.author.username}`)
            embed2.addField(`Channel:`, `${message.channel.name}`)
            embed2.addField(`Message:`, `${message.content}`)
            embed2.addField(`You have been muted`, `Depending on what you sent you may be unmuted once a staff member reviews the message.`)

        message.delete()
        let channel = bot.channels.cache.get('982091857788031006')
        message.member.roles.add("982080931219255296");
        message.author.send({embed: embed2})
        bot.channels.cache.get('982091857788031006').send({embed: embed});
    }
    

})



bot.on("messageDelete", async msg => {
    let logs = await msg.guild.fetchAuditLogs({type: 72});
    let entry = logs.entries.first();
    let embed = new Discord.MessageEmbed()
      embed.setTitle("**DELETED MESSAGE**")
      embed.setColor("#fc3c3c")
      embed.addField("Author", msg.author.tag, true)
      embed.addField("Channel", msg.channel.name, true)
      embed.addField("Message", msg.content)
      embed.addField("Executor", entry.executor)
      embed.setFooter(`Message ID: ${msg.id} | Author ID: ${msg.author.id}`);
      embed.setTimestamp()
    let channel = msg.guild.channels.cache.find(ch => ch.name ==="audit-logs");
    channel.send({embeds: embed});
 });



bot.on("messageCreate", async message => {


    // CHECK CHANNEL TYPE
    if (message.author.id === bot.user.id) return; 

    // SET PREFIX
    const prefix = botconfig.prefix;

    // CHECK PREFIX, DEFINE ARGS & COMMAND
    if (!message.content.startsWith(prefix)) return;
    let args = message.content.slice(prefix.length).trim().split(/ +/g);
    let cmd = args.shift().toLowerCase();
    let command;


    

    // RUN COMMANDS
    if (bot.commands.has(cmd)) {
        command = bot.commands.get(cmd);
    } else if (bot.aliases.has(cmd)) {
        command = bot.commands.get(bot.aliases.get(cmd));
    }
    try {
        command.run(bot, message, args, cmd);
    } catch (e) {
        return;
    }
    

})



  
bot.on('messageUpdate', (oldMessage, newMessage) => {
if (!oldMessage.author) return;
const MessageLog = newMessage.guild.channels.cache.find(ch => ch.name ==="audit-logs");
 var embed2 = new Discord.MessageEmbed()
 embed2.setTitle("**EDITED MESSAGE**")
 embed2.addField("Author", newMessage.author.tag, true)
 embed2.addField("Channel", newMessage.channel, true)
 embed2.addFields(
     {name: 'Original Message:', value: oldMessage},
     {name: 'Edited Message:', value: newMessage}    );
embed2.setTimestamp()
embed2.setColor('#392B47')
embed2.setFooter(`Message ID: ${newMessage.id} | Author ID: ${newMessage.author.id}`);
 MessageLog.send({embeds: embed2});
 });

bot.login(`OTgxNzE5NDczNzQyNTY1NDE2.GbN2Au.qK7oDoGCuGLB5xPCUzAKoBvQvcckGVv380_puU`);
