const mongoose = require("mongoose");

const dataSchema = mongoose.Schema({
    name: String,
    userID: String,
    lb: String,
    money: Number,
    moneyy: Number,
    KazanirBet: Number,
    KaybederBet: Number,
    KazanirToplam: Number,
    KaybederToplam: Number,
    Toplam: Number,
    daily: Number,
    upgrade: Number,
    compulsory: String,
    bank: Number,
    total: Number,
    work: Number,
    rig: Number,
    workupgrade: Number,
})

module.exports = mongoose.model("Data", dataSchema);