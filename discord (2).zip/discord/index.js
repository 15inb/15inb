
const Discord = require("discord.js");
const { Client, Intents } = require('discord.js');
const bot = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });
const botconfig = require("./botconfig.json");
const mongoose = require("mongoose");
const fs = require("fs");
var Changelog = require('generate-changelog');

mongoose.connect(botconfig.mongoPass, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});


bot.commands = new Discord.Collection();
bot.aliases = new Discord.Collection();


// READ COMMANDS FOLDER
fs.readdir("./commands/", (err, files) => {
    if (err) console.log(err);

    let jsfile = files.filter(f => f.split(".").pop() === "js");
    if (jsfile.length <= 0) {
        return console.log("No commands found!");
    }

    jsfile.forEach((f) => {
        if (!f.endsWith(".js")) return;
        let props = require(`./commands/${f}`);
        console.log(`${f} loaded!`);
        bot.commands.set(props.help.name, props);
        props.help.aliases.forEach(alias => {
            bot.aliases.set(alias, props.help.name);
        })
    })
})

// BOT ONLINE MESSAGE AND ACTIVITY MESSAGE
bot.on("ready", async () => {
    console.log(`${bot.user.username} is online on ${bot.guilds.cache.size} servers!`);
    bot.user.setActivity(`Serving ${bot.guilds.cache.size} servers!\n| >help`);

})





bot.on("message", message => {


    // CHECK CHANNEL TYPE
    if (message.channel.type === "dm") return;
    if (message.author.id === bot.user.id) return; 

    // SET PREFIX
    const prefix = botconfig.prefix;

    // CHECK PREFIX, DEFINE ARGS & COMMAND
    if (!message.content.startsWith(prefix)) return;
    let args = message.content.slice(prefix.length).trim().split(/ +/g);
    let cmd = args.shift().toLowerCase();
    let command;

    

    // RUN COMMANDS
    if (bot.commands.has(cmd)) {
        command = bot.commands.get(cmd);
    } else if (bot.aliases.has(cmd)) {
        command = bot.commands.get(bot.aliases.get(cmd));
    }
    try {
        command.run(bot, message, args, cmd);
    } catch (e) {
        return;
    }

    return Changelog.generate({ patch: true, repoUrl: 'https://github.com/lob/generate-changelog' })
.then(function (changelog) {
  fs.writeFileSync('./CHANGELOG.md', changelog);
  bot.channels.cache.get('962063209248993290').send(changelog)
});
    

})



bot.login(botconfig.token);
